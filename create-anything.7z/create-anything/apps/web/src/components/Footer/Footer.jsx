export function Footer() {
  const handleShhh = () => {
    // Redirect to the provided URL
    window.location.href = "https://v111.neocities.org/";
  };

  return (
    <footer className="bg-white dark:bg-[#121212] border-t border-gray-200 dark:border-gray-800 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
          <div className="col-span-2 md:col-span-1">
            <div className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-4">
              QR Master
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
              The simplest way to create and share QR codes for any content.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-4">
              Product
            </h4>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Generator
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Features
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-4">
              Company
            </h4>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  About
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Contact
                </a>
              </li>
              <li>
                <button
                  onClick={handleShhh}
                  className="mt-4 w-full px-6 py-3 bg-red-600 text-white rounded-xl font-black text-lg shadow-lg hover:bg-red-700 hover:scale-105 transition-all transform uppercase tracking-widest"
                >
                  SHHH
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-4">
              Legal
            </h4>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Privacy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Terms
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-gray-100 dark:border-gray-800 flex flex-col items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
          <div>
            © {new Date().getFullYear()} QR Master. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
}

import { useState, useCallback, useEffect } from "react";
import {
  Link,
  Type,
  Image as ImageIcon,
  Video,
  FileCode,
  File,
  Download,
  Copy,
  Loader2,
  Check,
  Settings,
} from "lucide-react";
import useUpload from "@/utils/useUpload";
import { toast } from "sonner";

export function QrGenerator() {
  const [activeTab, setActiveTab] = useState("link");
  const [inputValue, setInputValue] = useState("");
  const [generatedQr, setGeneratedQr] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [size, setSize] = useState(1000);
  const [upload, { loading: isUploading }] = useUpload();

  // Auto-generate when input changes (debounced)
  useEffect(() => {
    const timer = setTimeout(() => {
      if (
        inputValue &&
        (activeTab === "link" || activeTab === "text" || activeTab === "code")
      ) {
        handleGenerate();
      }
    }, 800);
    return () => clearTimeout(timer);
  }, [inputValue, size]);

  const handleGenerate = async () => {
    if (!inputValue) return;

    setIsGenerating(true);
    try {
      const response = await fetch(
        `/integrations/qr-code/generatebasicbase64?data=${encodeURIComponent(inputValue)}&size=${size}`,
      );
      if (!response.ok) throw new Error("Failed to generate QR code");

      const base64 = await response.text();
      // The API returns the raw base64 string, sometimes wrapped in quotes
      const cleanBase64 = base64.replace(/"/g, "");
      setGeneratedQr(`data:image/png;base64,${cleanBase64}`);
    } catch (error) {
      console.error(error);
      // toast.error("Failed to generate QR code");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      const { url, error } = await upload({ file });
      if (error) {
        toast.error(error);
        return;
      }
      setInputValue(url);
      // Auto generate after upload
      setIsGenerating(true);
      const response = await fetch(
        `/integrations/qr-code/generatebasicbase64?data=${encodeURIComponent(url)}&size=${size}`,
      );
      const base64 = await response.text();
      const cleanBase64 = base64.replace(/"/g, "");
      setGeneratedQr(`data:image/png;base64,${cleanBase64}`);
      setIsGenerating(false);
    } catch (err) {
      toast.error("Upload failed");
      setIsGenerating(false);
    }
  };

  const downloadQr = () => {
    if (!generatedQr) return;
    const link = document.createElement("a");
    link.href = generatedQr;
    link.download = "qrcode.png";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("QR Code downloaded");
  };

  const downloadFile = async () => {
    if (!inputValue) return;
    try {
      const response = await fetch(inputValue);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      const filename = inputValue.split("/").pop() || "download";
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast.success("File downloaded");
    } catch (err) {
      toast.error("Failed to download file");
    }
  };

  const copyToClipboard = async () => {
    if (!generatedQr) return;
    try {
      const response = await fetch(generatedQr);
      const blob = await response.blob();
      await navigator.clipboard.write([
        new ClipboardItem({ "image/png": blob }),
      ]);
      toast.success("Copied to clipboard");
    } catch (err) {
      toast.error("Failed to copy");
    }
  };

  return (
    <div className="relative lg:pl-8 flex justify-center lg:justify-end w-full">
      <div className="bg-white dark:bg-[#262626] rounded-2xl shadow-2xl dark:shadow-none dark:ring-1 dark:ring-gray-700 p-6 sm:p-8 w-full max-w-md">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 font-jetbrains-mono">
            Create QR Code
          </h3>
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500 font-mono">Size:</span>
            <select
              value={size}
              onChange={(e) => setSize(Number(e.target.value))}
              className="bg-gray-100 dark:bg-gray-800 border-none rounded text-xs py-1 px-2 text-gray-700 dark:text-gray-300"
            >
              <option value={500}>SD (500px)</option>
              <option value={1000}>HD (1000px)</option>
              <option value={2000}>2K (2000px)</option>
              <option value={4000}>4K (4000px)</option>
            </select>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex space-x-2 mb-6 overflow-x-auto pb-2 scrollbar-hide">
          <TabButton
            active={activeTab === "link"}
            onClick={() => setActiveTab("link")}
            icon={<Link size={16} />}
            label="Link"
          />
          <TabButton
            active={activeTab === "text"}
            onClick={() => setActiveTab("text")}
            icon={<Type size={16} />}
            label="Text"
          />
          <TabButton
            active={activeTab === "code"}
            onClick={() => setActiveTab("code")}
            icon={<FileCode size={16} />}
            label="Code"
          />
          <TabButton
            active={activeTab === "image"}
            onClick={() => setActiveTab("image")}
            icon={<ImageIcon size={16} />}
            label="Image"
          />
          <TabButton
            active={activeTab === "video"}
            onClick={() => setActiveTab("video")}
            icon={<Video size={16} />}
            label="Video"
          />
          <TabButton
            active={activeTab === "file"}
            onClick={() => setActiveTab("file")}
            icon={<File size={16} />}
            label="File / Zip"
          />
        </div>

        {/* Input Area */}
        <div className="mb-6 space-y-4">
          {activeTab === "link" && (
            <input
              type="url"
              placeholder="https://example.com"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-orange-500 font-jetbrains-mono"
            />
          )}

          {activeTab === "text" && (
            <textarea
              rows={3}
              placeholder="Enter your text here..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-orange-500 font-jetbrains-mono resize-none"
            />
          )}

          {activeTab === "code" && (
            <textarea
              rows={6}
              placeholder="Paste your code here..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-xl text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono text-sm resize-none whitespace-pre"
            />
          )}

          {(activeTab === "image" ||
            activeTab === "video" ||
            activeTab === "file") && (
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-6 text-center hover:border-orange-500 dark:hover:border-orange-500 transition-colors cursor-pointer relative">
              <input
                type="file"
                accept={
                  activeTab === "image"
                    ? "image/*"
                    : activeTab === "video"
                      ? "video/*"
                      : "*"
                }
                onChange={handleFileUpload}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                disabled={isUploading}
              />
              {isUploading ? (
                <div className="flex flex-col items-center">
                  <Loader2 className="animate-spin text-orange-500 mb-2" />
                  <span className="text-sm text-gray-500">Uploading...</span>
                </div>
              ) : (
                <>
                  <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/30 rounded-full flex items-center justify-center mx-auto mb-3">
                    {activeTab === "image" ? (
                      <ImageIcon className="text-orange-500" />
                    ) : activeTab === "video" ? (
                      <Video className="text-orange-500" />
                    ) : (
                      <File className="text-orange-500" />
                    )}
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-300 font-medium">
                    Click or drag to upload {activeTab}
                  </p>
                </>
              )}
            </div>
          )}

          {inputValue &&
            (activeTab === "image" ||
              activeTab === "video" ||
              activeTab === "file") &&
            !isUploading && (
              <div className="text-xs text-green-500 flex items-center gap-1">
                <Check size={12} /> File uploaded successfully
              </div>
            )}
        </div>

        {/* Generate Button - Changed text to imply it can be regenerated or just status */}
        <button
          onClick={handleGenerate}
          disabled={!inputValue || isGenerating || isUploading}
          className="w-full py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isGenerating ? <Loader2 className="animate-spin" /> : null}
          {isGenerating ? "Generating..." : "Generate QR Code"}
        </button>

        {/* Result Area */}
        {generatedQr && (
          <div className="mt-8 pt-8 border-t border-gray-100 dark:border-gray-700 animate-in fade-in slide-in-from-bottom-4">
            <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm mx-auto w-fit mb-6">
              <img
                src={generatedQr}
                alt="Generated QR Code"
                className="w-48 h-48 object-contain"
              />
            </div>

            <div className="flex flex-col gap-3">
              <div className="flex gap-3">
                <button
                  onClick={downloadQr}
                  className="flex-1 py-2 px-4 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2"
                >
                  <Download size={16} /> Download QR
                </button>
                <button
                  onClick={copyToClipboard}
                  className="flex-1 py-2 px-4 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2"
                >
                  <Copy size={16} /> Copy
                </button>
              </div>
              {["image", "video", "file"].includes(activeTab) && (
                <button
                  onClick={downloadFile}
                  className="w-full py-2 px-4 bg-orange-100 dark:bg-orange-900/20 hover:bg-orange-200 dark:hover:bg-orange-900/40 text-orange-700 dark:text-orange-300 rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2"
                >
                  <Download size={16} /> Download Uploaded File
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function TabButton({ active, onClick, icon, label }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
        active
          ? "bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 ring-1 ring-orange-500/20"
          : "text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

export function TrustSection() {
  return (
    <section className="py-12 sm:py-16 bg-white dark:bg-[#121212] border-t border-gray-100 dark:border-gray-800">
      <div className="max-w-5xl mx-auto px-4 sm:px-8 text-center">
        {/* "Trusted by" text */}
        <p className="text-sm text-gray-400 dark:text-gray-500 mb-8 sm:mb-12 font-jetbrains-mono">
          Used by creators and businesses worldwide
        </p>

        {/* Company logos row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-8 sm:gap-12 lg:gap-16 opacity-60 items-center justify-items-center">
          <div className="text-gray-400 dark:text-gray-500 font-bold text-xl">
            LinkTree
          </div>
          <div className="text-gray-400 dark:text-gray-500 font-bold text-xl">
            Shopify
          </div>
          <div className="text-gray-400 dark:text-gray-500 font-bold text-xl">
            Instagram
          </div>
          <div className="text-gray-400 dark:text-gray-500 font-bold text-xl col-span-2 sm:col-span-1">
            Youtube
          </div>
          <div className="text-gray-400 dark:text-gray-500 font-bold text-xl hidden sm:block lg:block">
            TikTok
          </div>
        </div>
      </div>
    </section>
  );
}

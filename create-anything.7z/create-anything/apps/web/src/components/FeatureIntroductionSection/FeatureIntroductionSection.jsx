import {
  Zap,
  Shield,
  Share2,
  Image,
  Smartphone,
  BarChart3,
} from "lucide-react";

const features = [
  {
    title: "Instant Generation",
    desc: "Create QR codes in milliseconds. No waiting, no processing time.",
    icon: <Zap className="text-white" size={24} />,
  },
  {
    title: "Multimedia Support",
    desc: "Upload images, videos, and PDFs directly to generate QR codes.",
    icon: <Image className="text-white" size={24} />,
  },
  {
    title: "Mobile Optimized",
    desc: "Generated codes are optimized for all mobile cameras and scanners.",
    icon: <Smartphone className="text-white" size={24} />,
  },
  {
    title: "Secure & Private",
    desc: "Your data is encrypted and secure. We respect your privacy.",
    icon: <Shield className="text-white" size={24} />,
  },
  {
    title: "Easy Sharing",
    desc: "Download in high quality PNG format or copy directly to clipboard.",
    icon: <Share2 className="text-white" size={24} />,
  },
  {
    title: "Analytics Ready",
    desc: "Track scans and engagement with our premium analytics tools.",
    icon: <BarChart3 className="text-white" size={24} />,
  },
];

export function FeatureIntroductionSection() {
  return (
    <section className="py-16 sm:py-24 bg-gray-50 dark:bg-[#1E1E1E]">
      <div className="max-w-6xl mx-auto px-4 sm:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-gray-100 mb-4 font-jetbrains-mono">
            Why use QR Master?
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 font-jetbrains-mono">
            Everything you need to bridge the physical and digital worlds.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white dark:bg-[#262626] p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 hover:shadow-md transition-shadow"
            >
              <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-orange-500/20">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-2 font-jetbrains-mono">
                {feature.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 font-jetbrains-mono leading-relaxed">
                {feature.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

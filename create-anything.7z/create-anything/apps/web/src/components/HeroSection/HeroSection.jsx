import { QrGenerator } from "../QrGenerator/QrGenerator";

export function HeroSection() {
  return (
    <section className="pt-16 pb-12 sm:pb-20 bg-gray-50 dark:bg-[#1E1E1E] overflow-hidden min-h-screen flex flex-col justify-center">
      <div className="max-w-6xl mx-auto px-4 sm:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Left column: Hero text and CTA */}
          <div className="space-y-6 sm:space-y-8 pt-4 sm:pt-8 text-center lg:text-left">
            {/* Main headline */}
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold text-gray-900 dark:text-gray-100 leading-tight font-jetbrains-mono">
              Generate QR Codes for{" "}
              <span className="text-orange-500">Everything</span>
            </h1>

            {/* Subtext paragraph */}
            <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-300 leading-relaxed max-w-2xl font-jetbrains-mono">
              Instantly create high-resolution QR codes for links, text, code
              snippets, files, videos, and more. Unlimited generation, no
              sign-up required.
            </p>

            {/* Feature tags */}
            <div className="flex flex-wrap gap-3 justify-center lg:justify-start pt-2">
              {[
                "Unlimited",
                "4K Resolution",
                "Any File Type",
                "Free Forever",
              ].map((tag) => (
                <span
                  key={tag}
                  className="px-3 py-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full text-sm text-gray-600 dark:text-gray-400"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Right column: QR Generator Tool */}
          <QrGenerator />
        </div>
      </div>
    </section>
  );
}

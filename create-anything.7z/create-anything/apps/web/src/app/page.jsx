import { Toaster } from "sonner";
import { Header } from "../components/Header/Header";
import { HeroSection } from "../components/HeroSection/HeroSection";
import { TrustSection } from "../components/TrustSection/TrustSection";
import { FeatureIntroductionSection } from "../components/FeatureIntroductionSection/FeatureIntroductionSection";
import { Footer } from "../components/Footer/Footer";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white dark:bg-[#121212]">
      <Toaster position="top-center" richColors />
      <Header />
      <HeroSection />
      <TrustSection />
      <FeatureIntroductionSection />
      <Footer />
    </div>
  );
}

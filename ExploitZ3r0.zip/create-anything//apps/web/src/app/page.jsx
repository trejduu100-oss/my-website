import React, { memo, useMemo } from "react";
import {
  Gamepad2,
  Gamepad,
  Joystick,
  QrCode,
  Globe,
  Link,
  Link2,
  Zap,
} from "lucide-react";
import * as motion from "motion/react-client";

// Memoized link component for better performance
const LinkCard = memo(({ link, index }) => {
  const Icon = link.icon;

  return (
    <motion.a
      href={link.url}
      target="_blank"
      rel="noopener noreferrer"
      initial={{ opacity: 0, x: -50, rotate: -10 }}
      animate={{ opacity: 1, x: 0, rotate: 0 }}
      transition={{
        delay: index * 0.1,
        duration: 0.5,
        type: "spring",
        bounce: 0.5,
      }}
      whileHover={{
        scale: 1.05,
        rotate: 2,
        y: -5,
      }}
      whileTap={{
        scale: 0.95,
        rotate: -2,
      }}
      className="flex items-center gap-3 sm:gap-4 rounded-2xl sm:rounded-3xl bg-gradient-to-r from-gray-50 to-gray-100 p-4 sm:p-5 shadow-lg hover:shadow-2xl transition-all duration-300 border-4 border-white group"
    >
      <motion.div
        whileHover={{ rotate: 360 }}
        transition={{ duration: 0.6 }}
        className={`rounded-2xl ${link.color} p-3 sm:p-3.5 shadow-lg ${link.shadowColor} text-white flex-shrink-0`}
      >
        <Icon size={24} className="sm:w-7 sm:h-7" strokeWidth={2.5} />
      </motion.div>
      <div className="flex-1 min-w-0">
        <h3 className="font-black text-gray-800 text-base sm:text-lg group-hover:text-purple-600 transition-colors truncate">
          {link.name}
        </h3>
        <p className="text-xs sm:text-sm text-gray-500 font-semibold truncate">
          {link.description}
        </p>
      </div>
      <motion.div
        className="text-gray-400 group-hover:text-purple-600 transition-colors flex-shrink-0"
        whileHover={{ x: 5 }}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M5 12h14" />
          <path d="m12 5 7 7-7 7" />
        </svg>
      </motion.div>
    </motion.a>
  );
});

LinkCard.displayName = "LinkCard";

export default function Home() {
  const links = useMemo(
    () => [
      {
        name: "Games",
        description: "Netlify",
        url: "https://gamecry.netlify.app/",
        icon: Gamepad2,
        color: "bg-gradient-to-br from-purple-400 to-purple-600",
        shadowColor: "shadow-purple-500/50",
      },
      {
        name: "Games by ExploitZ3r0",
        description: "Render",
        url: "https://games-by-exploitz3r01.onrender.com/",
        icon: Gamepad,
        color: "bg-gradient-to-br from-blue-400 to-blue-600",
        shadowColor: "shadow-blue-500/50",
      },
      {
        name: "Games ExploitZ3r0",
        description: "Vercel",
        url: "https://games-exploitz3r0.vercel.app/",
        icon: Joystick,
        color: "bg-gradient-to-br from-green-400 to-green-600",
        shadowColor: "shadow-green-500/50",
      },
      {
        name: "QR Code Generator",
        description: "Created.app",
        url: "https://cry11.created.app/",
        icon: QrCode,
        color: "bg-gradient-to-br from-yellow-400 to-yellow-600",
        shadowColor: "shadow-yellow-500/50",
      },
      {
        name: "V111",
        description: "Neocities",
        url: "https://v111.neocities.org/",
        icon: Globe,
        color: "bg-gradient-to-br from-pink-400 to-pink-600",
        shadowColor: "shadow-pink-500/50",
      },
      {
        name: "URL GPT",
        description: "Lovable.app",
        url: "https://urlgpt.lovable.app",
        icon: Link,
        color: "bg-gradient-to-br from-cyan-400 to-cyan-600",
        shadowColor: "shadow-cyan-500/50",
      },
      {
        name: "URL GPT",
        description: "Created.app",
        url: "https://urlgpt.created.app",
        icon: Link2,
        color: "bg-gradient-to-br from-orange-400 to-orange-600",
        shadowColor: "shadow-orange-500/50",
      },
      {
        name: "ExploitZ3r0",
        description: "Riste aka ExploitZ3r0",
        url: "https://cry.base44.app/",
        icon: Link2,
        color: "bg-gradient-to-br from-orange-400 to-orange-600",
        shadowColor: "shadow-orange-500/50",
      },
    ],
    [],
  );

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-white font-sans">
      {/* Playful Background Decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[10%] left-[5%] w-[200px] h-[200px] md:w-[300px] md:h-[300px] bg-yellow-300/40 rounded-full blur-[80px] will-change-transform" />
        <div className="absolute top-[60%] right-[10%] w-[250px] h-[250px] md:w-[350px] md:h-[350px] bg-cyan-300/40 rounded-full blur-[90px] will-change-transform" />
        <div className="absolute bottom-[10%] left-[30%] w-[200px] h-[200px] md:w-[400px] md:h-[400px] bg-pink-300/40 rounded-full blur-[100px] will-change-transform" />
        <div className="absolute top-[30%] right-[30%] w-[150px] h-[150px] md:w-[250px] md:h-[250px] bg-green-300/30 rounded-full blur-[70px] will-change-transform" />
      </div>

      <div className="relative z-10 flex min-h-screen items-center justify-center p-4 sm:p-6 md:p-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{
            duration: 0.6,
            type: "spring",
            bounce: 0.4,
          }}
          className="w-full max-w-md"
        >
          <div className="rounded-[2rem] bg-white p-6 sm:p-8 shadow-2xl">
            <div className="space-y-3 sm:space-y-4">
              {links.map((link, index) => (
                <LinkCard
                  key={`${link.url}-${index}`}
                  link={link}
                  index={index}
                />
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Fun floating animation styles */}
      <style jsx global>{`
        @keyframes float {
          0%, 100% { 
            transform: translateY(0px) rotate(0deg);
          }
          50% { 
            transform: translateY(-20px) rotate(5deg);
          }
        }
        
        .absolute.blur-\\[80px\\],
        .absolute.blur-\\[90px\\],
        .absolute.blur-\\[100px\\],
        .absolute.blur-\\[70px\\] {
          animation: float 6s ease-in-out infinite;
        }
        
        .absolute.blur-\\[90px\\] {
          animation-delay: 1s;
          animation-duration: 7s;
        }
        
        .absolute.blur-\\[100px\\] {
          animation-delay: 2s;
          animation-duration: 8s;
        }
        
        .absolute.blur-\\[70px\\] {
          animation-delay: 0.5s;
          animation-duration: 5s;
        }
      `}</style>
    </div>
  );
}
